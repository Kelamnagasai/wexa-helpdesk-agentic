import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../api';

export default function Login(){
  const nav = useNavigate();
  const [email, setEmail] = useState('admin@example.com');
  const [password, setPassword] = useState('password');
  const [err, setErr] = useState(null);

  async function submit(e){
    e.preventDefault();
    setErr(null);
    try{
      const { token } = await api('/api/auth/login', { method:'POST', body: JSON.stringify({ email, password }) });
      localStorage.setItem('token', token);
      nav('/');
    }catch(e){ setErr(e.message); }
  }

  return (
    <div style={{maxWidth:420, margin:'40px auto', fontFamily:'Inter, system-ui'}}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <button>Login</button>
      </form>
      {err && <p style={{color:'crimson'}}>{err}</p>}
      <p>No account? <Link to="/register">Register</Link></p>
    </div>
  )
}
