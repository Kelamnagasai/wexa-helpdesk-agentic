import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';

export default function Tickets(){
  const [tickets, setTickets] = useState([]);
  const [title, setTitle] = useState('Refund for double charge');
  const [description, setDescription] = useState('I was charged twice for order #1234');
  const [err, setErr] = useState(null);

  async function load(){ setTickets(await api('/api/tickets')); }
  useEffect(()=>{ load(); }, []);

  async function create(e){
    e.preventDefault();
    setErr(null);
    try{
      await api('/api/tickets', { method:'POST', body: JSON.stringify({ title, description }) });
      setTitle(''); setDescription('');
      await load();
    }catch(e){ setErr(e.message); }
  }

  return (
    <div>
      <h2>Tickets</h2>
      <form onSubmit={create} style={{marginBottom:20}}>
        <input placeholder="title" value={title} onChange={e=>setTitle(e.target.value)} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <textarea placeholder="description" value={description} onChange={e=>setDescription(e.target.value)} style={{display:'block', width:'100%', padding:8, margin:'8px 0', height:100}}/>
        <button>Create Ticket</button>
      </form>
      {err && <p style={{color:'crimson'}}>{err}</p>}
      <ul>
        {tickets.map(t=>(
          <li key={t._id}>
            <Link to={`/tickets/${t._id}`}>{t.title}</Link> — <b>{t.status}</b> ({t.category})
          </li>
        ))}
      </ul>
    </div>
  )
}
