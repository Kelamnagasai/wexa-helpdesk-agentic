import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function KB(){
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ title:'', body:'', tags:'', status:'draft' });

  async function load(){ setList(await api('/api/kb')); }
  useEffect(()=>{ load(); }, []);

  async function create(e){
    e.preventDefault();
    const payload = { ...form, tags: form.tags.split(',').map(s=>s.trim()).filter(Boolean) };
    await api('/api/kb', { method:'POST', body: JSON.stringify(payload) });
    setForm({ title:'', body:'', tags:'', status:'draft' }); await load();
  }

  return (
    <div>
      <h2>Knowledge Base</h2>
      <form onSubmit={create}>
        <input placeholder="title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <textarea placeholder="body" value={form.body} onChange={e=>setForm({...form, body:e.target.value})} style={{display:'block', width:'100%', padding:8, margin:'8px 0', height:100}}/>
        <input placeholder="tags comma-separated" value={form.tags} onChange={e=>setForm({...form, tags:e.target.value})} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <select value={form.status} onChange={e=>setForm({...form, status:e.target.value})}>
          <option value="draft">draft</option>
          <option value="published">published</option>
        </select>
        <button>Create</button>
      </form>

      <ul>
        {list.map(a=>(<li key={a._id}><b>{a.title}</b> — {a.status} — tags: {(a.tags||[]).join(', ')}</li>))}
      </ul>
    </div>
  )
}
