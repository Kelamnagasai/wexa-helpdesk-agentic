import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api';

export default function TicketDetail(){
  const { id } = useParams();
  const [t, setT] = useState(null);
  const [sugg, setSugg] = useState(null);
  const [logs, setLogs] = useState([]);
  const [reply, setReply] = useState('Thanks for reaching out. Closing this.');

  async function load(){
    setT(await api(`/api/tickets/${id}`));
    try{ setSugg(await api(`/api/agent/suggestion/${id}`)); }catch{ setSugg(null); }
    setLogs(await api(`/api/audit/tickets/${id}`));
  }
  useEffect(()=>{ load(); }, [id]);

  async function send(action){
    await api(`/api/tickets/${id}/reply`, { method:'POST', body: JSON.stringify({ message: reply, action }) });
    await load();
  }

  if(!t) return <p>Loading…</p>;

  return (
    <div>
      <h2>{t.title}</h2>
      <p>Status: <b>{t.status}</b> | Category: <b>{t.category}</b></p>

      {sugg && (
        <div style={{padding:12, border:'1px solid #ddd', margin:'12px 0'}}>
          <h3>Agent Suggestion</h3>
          <p>{sugg.draftReply}</p>
          <p>Confidence: {sugg.confidence}</p>
          <p>AutoClosed: {String(sugg.autoClosed)}</p>
        </div>
      )}

      <div>
        <h3>Replies</h3>
        <ul>
          {(t.replies||[]).map((r,i)=>(<li key={i}><b>{r.by}</b>: {r.message} <small>{new Date(r.at).toLocaleString()}</small></li>))}
        </ul>
      </div>

      <div style={{marginTop:12}}>
        <textarea value={reply} onChange={e=>setReply(e.target.value)} style={{width:'100%', height:80}}/>
        <div style={{display:'flex', gap:8, marginTop:8}}>
          <button onClick={()=>send('resolve')}>Send & Resolve</button>
          <button onClick={()=>send('close')}>Send & Close</button>
          <button onClick={()=>send('reopen')}>Reopen</button>
        </div>
      </div>

      <div style={{marginTop:20}}>
        <h3>Audit Timeline</h3>
        <ul>
          {logs.map(l=>(<li key={l._id}><code>{l.action}</code> — {new Date(l.timestamp).toLocaleString()}</li>))}
        </ul>
      </div>
    </div>
  )
}
