import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';

export default function Register(){
  const nav = useNavigate();
  const [name, setName] = useState('Test User');
  const [email, setEmail] = useState('test@example.com');
  const [password, setPassword] = useState('password');
  const [err, setErr] = useState(null);

  async function submit(e){
    e.preventDefault();
    setErr(null);
    try{
      const { token } = await api('/api/auth/register', { method:'POST', body: JSON.stringify({ name, email, password }) });
      localStorage.setItem('token', token);
      nav('/');
    }catch(e){ setErr(e.message); }
  }

  return (
    <div style={{maxWidth:420, margin:'40px auto', fontFamily:'Inter, system-ui'}}>
      <h2>Register</h2>
      <form onSubmit={submit}>
        <input placeholder="name" value={name} onChange={e=>setName(e.target.value)} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} style={{display:'block', width:'100%', padding:8, margin:'8px 0'}}/>
        <button>Create Account</button>
      </form>
      {err && <p style={{color:'crimson'}}>{err}</p>}
    </div>
  )
}
