import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function Settings(){
  const [cfg, setCfg] = useState(null);
  const [err, setErr] = useState(null);

  async function load(){ setCfg(await api('/api/config')); }
  useEffect(()=>{ load(); }, []);

  async function save(e){
    e.preventDefault();
    setErr(null);
    try{
      const res = await api('/api/config', { method:'PUT', body: JSON.stringify(cfg) });
      setCfg(res);
    }catch(e){ setErr(e.message); }
  }

  if(!cfg) return <p>Loading…</p>;

  return (
    <div>
      <h2>Settings</h2>
      <form onSubmit={save}>
        <label>
          Auto Close Enabled:
          <input type="checkbox" checked={cfg.autoCloseEnabled} onChange={e=>setCfg({...cfg, autoCloseEnabled: e.target.checked})}/>
        </label>
        <br/>
        <label>
          Confidence Threshold:
          <input type="number" step="0.01" value={cfg.confidenceThreshold} onChange={e=>setCfg({...cfg, confidenceThreshold: Number(e.target.value)})}/>
        </label>
        <br/>
        <label>
          SLA Hours:
          <input type="number" value={cfg.slaHours} onChange={e=>setCfg({...cfg, slaHours: Number(e.target.value)})}/>
        </label>
        <br/>
        <button>Save</button>
      </form>
      {err && <p style={{color:'crimson'}}>{err}</p>}
    </div>
  )
}
