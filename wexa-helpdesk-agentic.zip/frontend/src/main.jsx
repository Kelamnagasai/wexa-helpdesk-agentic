import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import Tickets from './pages/Tickets.jsx'
import TicketDetail from './pages/TicketDetail.jsx'
import KB from './pages/KB.jsx'
import Settings from './pages/Settings.jsx'

function Layout({ children }){
  const token = localStorage.getItem('token');
  const payload = token ? JSON.parse(atob(token.split('.')[1])) : null;
  const role = payload?.role;
  return (
    <div style={{fontFamily:'Inter, system-ui', maxWidth: 1000, margin:'0 auto', padding:20}}>
      <nav style={{display:'flex', gap:12, marginBottom:20}}>
        <Link to="/">Tickets</Link>
        {role==='admin' && <Link to="/kb">KB</Link>}
        {role==='admin' && <Link to="/settings">Settings</Link>}
        {!token ? <Link to="/login">Login</Link> : <button onClick={()=>{localStorage.removeItem('token'); location.href='/login';}}>Logout</button>}
      </nav>
      {children}
    </div>
  )
}

function App(){
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout><Tickets/></Layout>} />
        <Route path="/tickets/:id" element={<Layout><TicketDetail/></Layout>} />
        <Route path="/kb" element={<Layout><KB/></Layout>} />
        <Route path="/settings" element={<Layout><Settings/></Layout>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/register" element={<Register/>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')).render(<App/>)
