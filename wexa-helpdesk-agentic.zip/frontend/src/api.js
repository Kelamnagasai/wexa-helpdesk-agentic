const API = import.meta.env.VITE_API || 'http://localhost:8080';
export async function api(path, opts={}){
  const token = localStorage.getItem('token');
  const headers = { 'Content-Type':'application/json', ...(opts.headers||{}) };
  if(token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${API}${path}`, { ...opts, headers });
  if(!res.ok){
    let msg = 'Request failed';
    try{ const j = await res.json(); msg = j.error || JSON.stringify(j); } catch {}
    throw new Error(msg);
  }
  return res.json();
}
export default API;
