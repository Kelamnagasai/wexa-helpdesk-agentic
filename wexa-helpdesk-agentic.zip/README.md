# Wexa AI — Smart Helpdesk with Agentic Triage (Track A: MERN)

End-to-end helpdesk where users raise tickets and an **agentic workflow** triages them:
classifies → retrieves KB → drafts reply → auto-closes or assigns to human, with full audit logs.

## Quick Start (Docker)
```bash
docker compose up
```
- API: http://localhost:8080
- Frontend: http://localhost:5173
- Seed accounts: `admin@example.com`, `agent@example.com`, `user@example.com` (password: `password`)

## Tech
- **Backend**: Node 20 / Express / Mongoose / JWT / Zod / Helmet / Rate-limit
- **Frontend**: React + Vite + Router
- **Agent**: Deterministic stub (`STUB_MODE=true`), rule-based classification & templated drafting
- **Observability**: JSON logs with latency; audit timeline with `traceId`
- **Security**: input validation, JWT auth, role-based access, rate limit, no stack traces
- **DevOps**: Docker Compose (mongo, api, client), seed script

## Acceptance Criteria Mapping
1. Register/login, create ticket → **OK**
2. Creating ticket triggers triage; `AgentSuggestion` persisted → **OK**
3. If confidence ≥ threshold & auto-close on → ticket resolved with system reply → **OK**
4. Else ticket → `waiting_human` (triaged) and agents can reply/resolve/close → **OK**
5. Audit timeline with ordered steps & `traceId` → **OK**
6. KB search with regex query in API → **OK**
7. Runs with `STUB_MODE=true` and no external keys → **OK**
8. `docker compose up` brings stack with seed data → **OK**

## Env
See `backend/.env.example`. Defaults are wired via docker-compose.

## API (key endpoints)
- Auth: `POST /api/auth/register`, `POST /api/auth/login`
- KB: `GET /api/kb?query=...`, `POST/PUT/DELETE /api/kb/:id` (admin)
- Tickets: `POST /api/tickets`, `GET /api/tickets`, `GET /api/tickets/:id`,
  `POST /api/tickets/:id/reply` (agent/admin), `POST /api/tickets/:id/assign` (agent/admin)
- Agent: `POST /api/agent/triage`, `GET /api/agent/suggestion/:ticketId`
- Config: `GET/PUT /api/config` (admin)
- Audit: `GET /api/audit/tickets/:id`

## Testing
Minimal Jest scaffolding is included. In a full CI you'd run the API in test mode and hit endpoints with Supertest.

## Loom / Demo Script (≤5 min)
1. Login as **admin**, show KB CRUD & Settings (threshold toggle)
2. Login as **user**, create ticket → watch status update to `resolved` or `triaged`
3. Login as **agent**, open the ticket, edit/send reply, resolve/close
4. Show **Audit Timeline** and **Agent Suggestion**

## Notes & Gotchas
- The agent is a **state machine** encoded in `src/utils/agent.js` with steps: plan → classify → retrieve → draft → decision → logging.
- All timestamps are ISO; audit events are **immutable** (append-only).
- For production: add refresh tokens, stronger secrets, queues (BullMQ) and per-category thresholds.
