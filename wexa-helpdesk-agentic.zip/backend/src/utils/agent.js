import { v4 as uuidv4 } from 'uuid';
import Article from '../models/Article.js';
import AgentSuggestion from '../models/AgentSuggestion.js';
import Ticket from '../models/Ticket.js';
import AuditLog from '../models/AuditLog.js';
import Config from '../models/Config.js';

/** Deterministic LLM stub with simple heuristics */
function classifyStub(text){
  const t = text.toLowerCase();
  let category = 'other';
  let score = 0.3;
  const rules = [
    { cat:'billing', words:['refund','invoice','payment','charged','card','billing']},
    { cat:'tech', words:['error','bug','stack','500','crash','login','auth','issue']},
    { cat:'shipping', words:['delivery','shipment','tracking','package','courier','delay']},
  ];
  for(const r of rules){
    let hits = 0;
    for(const w of r.words){
      if(t.includes(w)) hits++;
    }
    if(hits>=2){ category = r.cat; score = Math.min(0.9, 0.5 + hits*0.1); break; }
    if(hits===1 && category==='other'){ category = r.cat; score = Math.max(score, 0.5); }
  }
  return { predictedCategory: category, confidence: Number(score.toFixed(2)) };
}

async function retrieveKB(query){
  const q = query.toLowerCase();
  const all = await Article.find({ status: 'published' });
  const scored = all.map(a=>{
    const hay = (a.title + ' ' + a.body + ' ' + (a.tags||[]).join(' ')).toLowerCase();
    let score = 0;
    for(const tok of q.split(/\W+/)){
      if(!tok) continue;
      if(hay.includes(tok)) score += 1;
    }
    return { id: a._id, title: a.title, score };
  }).sort((a,b)=>b.score-a.score).slice(0,3);
  return scored.map(s=>s.id);
}

function draftReplyStub(ticket, articles){
  const refs = articles.map((id, i)=>`[${i+1}]`).join(' ');
  return `Hi! We looked into your ticket: "${ticket.title}". Based on our knowledge base ${refs}, here's a suggested resolution. Please check the referenced articles for detailed steps. If you still face issues, reply and a human agent will assist.`;
}

export async function runTriage(ticketId){
  const traceId = uuidv4();
  const start = Date.now();
  const ticket = await Ticket.findById(ticketId);
  if(!ticket) throw new Error('Ticket not found');

  // PLAN
  await AuditLog.create({ ticketId, traceId, actor:'system', action:'PLAN_STARTED', meta:{}, timestamp:new Date() });

  // CLASSIFY
  const cls = classifyStub(ticket.title + ' ' + ticket.description);
  await AuditLog.create({ ticketId, traceId, actor:'system', action:'AGENT_CLASSIFIED', meta:cls, timestamp:new Date() });

  // RETRIEVE
  const articleIds = await retrieveKB(ticket.title + ' ' + ticket.description);
  await AuditLog.create({ ticketId, traceId, actor:'system', action:'KB_RETRIEVED', meta:{ articleIds }, timestamp:new Date() });

  // DRAFT
  const draftReply = draftReplyStub(ticket, articleIds);
  await AuditLog.create({ ticketId, traceId, actor:'system', action:'DRAFT_GENERATED', meta:{ draftReply }, timestamp:new Date() });

  const cfg = await Config.findOne() || await Config.create({});
  let autoClosed = false;
  let newStatus = 'waiting_human';
  let reply = null;

  if(cfg.autoCloseEnabled && cls.confidence >= cfg.confidenceThreshold){
    autoClosed = true;
    newStatus = 'resolved';
    reply = { by:'system', message: draftReply, at: new Date() };
  } else {
    newStatus = 'waiting_human';
  }

  const suggestion = await AgentSuggestion.create({
    ticketId,
    predictedCategory: cls.predictedCategory,
    articleIds,
    draftReply,
    confidence: cls.confidence,
    autoClosed,
    modelInfo: { provider: process.env.STUB_MODE==='true'?'stub':'llm', model: 'rule-based-1', promptVersion: 'v1' },
    latencyMs: Date.now()-start
  });

  ticket.category = cls.predictedCategory;
  ticket.agentSuggestionId = suggestion._id;
  ticket.status = autoClosed ? 'resolved' : 'triaged';
  if(reply) ticket.replies.push(reply);
  await ticket.save();

  await AuditLog.create({ ticketId, traceId, actor:'system', action: autoClosed ? 'AUTO_CLOSED' : 'ASSIGNED_TO_HUMAN', meta:{ suggestionId: suggestion._id }, timestamp:new Date() });

  return { suggestionId: suggestion._id, traceId };
}
