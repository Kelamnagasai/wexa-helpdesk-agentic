export function requestLogger(req,res,next){
  const start = Date.now();
  res.on('finish', ()=>{
    const latency = Date.now() - start;
    const log = {
      level: 'info',
      method: req.method,
      path: req.originalUrl,
      status: res.statusCode,
      latencyMs: latency
    };
    console.log(JSON.stringify(log));
  });
  next();
}
