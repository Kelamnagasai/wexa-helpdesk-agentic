import { z } from 'zod';

export const schemas = {
  register: z.object({
    name: z.string().min(1),
    email: z.string().email(),
    password: z.string().min(6)
  }),
  login: z.object({
    email: z.string().email(),
    password: z.string().min(6)
  }),
  kbCreate: z.object({
    title: z.string().min(1),
    body: z.string().min(1),
    tags: z.array(z.string()).default([]),
    status: z.enum(['draft','published']).default('draft')
  }),
  kbUpdate: z.object({
    title: z.string().min(1).optional(),
    body: z.string().min(1).optional(),
    tags: z.array(z.string()).optional(),
    status: z.enum(['draft','published']).optional()
  }),
  ticketCreate: z.object({
    title: z.string().min(1),
    description: z.string().min(1),
    category: z.enum(['billing','tech','shipping','other']).optional().default('other'),
    attachments: z.array(z.string()).optional().default([])
  }),
  reply: z.object({
    message: z.string().min(1),
    action: z.enum(['resolve','close','reopen','none']).default('none')
  }),
  assign: z.object({
    assigneeId: z.string().min(1)
  }),
  config: z.object({
    autoCloseEnabled: z.boolean(),
    confidenceThreshold: z.number().min(0).max(1),
    slaHours: z.number().min(1).max(720)
  })
};

export function validate(schema){
  return (req,res,next)=>{
    const parsed = schema.safeParse(req.body);
    if(!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
    req.body = parsed.data;
    next();
  };
}
