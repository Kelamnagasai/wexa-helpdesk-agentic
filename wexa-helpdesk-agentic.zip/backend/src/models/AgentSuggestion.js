import mongoose from 'mongoose';

const suggestionSchema = new mongoose.Schema({
  ticketId: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket', required: true },
  predictedCategory: { type: String, enum: ['billing','tech','shipping','other'], required: true },
  articleIds: { type: [mongoose.Schema.Types.ObjectId], ref: 'Article', default: [] },
  draftReply: { type: String, required: true },
  confidence: { type: Number, required: true },
  autoClosed: { type: Boolean, default: false },
  modelInfo: { type: Object, default: {} },
  latencyMs: { type: Number, default: 0 },
}, { timestamps: true });

export default mongoose.model('AgentSuggestion', suggestionSchema);
