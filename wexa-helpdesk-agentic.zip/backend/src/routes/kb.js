import express from 'express';
import Article from '../models/Article.js';
import { auth, requireRole } from '../middleware/auth.js';
import { schemas, validate } from '../utils/validator.js';

const router = express.Router();

router.get('/', auth(false), async (req,res)=>{
  const query = (req.query.query || '').toString().toLowerCase();
  const filter = query ? {
    $or: [
      { title: { $regex: query, $options: 'i' } },
      { body: { $regex: query, $options: 'i' } },
      { tags: { $elemMatch: { $regex: query, $options: 'i' } } }
    ]
  } : {};
  const articles = await Article.find(filter).sort({ updatedAt: -1 }).limit(50);
  res.json(articles);
});

router.post('/', auth(), requireRole('admin'), validate(schemas.kbCreate), async (req,res)=>{
  const art = await Article.create(req.body);
  res.status(201).json(art);
});

router.put('/:id', auth(), requireRole('admin'), validate(schemas.kbUpdate), async (req,res)=>{
  const art = await Article.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if(!art) return res.status(404).json({ error: 'Not found' });
  res.json(art);
});

router.delete('/:id', auth(), requireRole('admin'), async (req,res)=>{
  await Article.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

export default router;
