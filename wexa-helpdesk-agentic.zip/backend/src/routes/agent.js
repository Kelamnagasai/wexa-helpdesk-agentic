import express from 'express';
import AgentSuggestion from '../models/AgentSuggestion.js';
import { runTriage } from '../utils/agent.js';
import { auth, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.post('/triage', auth(), requireRole('admin','agent'), async (req,res)=>{
  const { ticketId } = req.body;
  if(!ticketId) return res.status(400).json({ error: 'ticketId required' });
  const out = await runTriage(ticketId);
  res.json(out);
});

router.get('/suggestion/:ticketId', auth(), async (req,res)=>{
  const s = await AgentSuggestion.findOne({ ticketId: req.params.ticketId }).sort({ createdAt: -1 });
  if(!s) return res.status(404).json({ error: 'Not found' });
  res.json(s);
});

export default router;
