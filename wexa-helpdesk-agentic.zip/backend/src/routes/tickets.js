import express from 'express';
import Ticket from '../models/Ticket.js';
import User from '../models/User.js';
import AgentSuggestion from '../models/AgentSuggestion.js';
import AuditLog from '../models/AuditLog.js';
import { auth, requireRole } from '../middleware/auth.js';
import { schemas, validate } from '../utils/validator.js';
import { runTriage } from '../utils/agent.js';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

router.post('/', auth(), validate(schemas.ticketCreate), async (req,res)=>{
  const ticket = await Ticket.create({ ...req.body, createdBy: req.user.id });
  const trace = await AuditLog.create({ ticketId: ticket._id, traceId: uuidv4(), actor:'user', action:'TICKET_CREATED', meta:{}, timestamp:new Date() });
  // fire and forget triage (no queue for simplicity)
  runTriage(ticket._id).catch(err=>console.error('triage error', err.message));
  res.status(201).json(ticket);
});

router.get('/', auth(), async (req,res)=>{
  const { status, mine } = req.query;
  const filter = {};
  if(status) filter.status = status;
  if(mine === 'true') filter.createdBy = req.user.id;
  const tickets = await Ticket.find(filter).sort({ updatedAt: -1 }).limit(100);
  res.json(tickets);
});

router.get('/:id', auth(), async (req,res)=>{
  const t = await Ticket.findById(req.params.id);
  if(!t) return res.status(404).json({ error: 'Not found' });
  res.json(t);
});

router.post('/:id/reply', auth(), requireRole('agent','admin'), validate(schemas.reply), async (req,res)=>{
  const t = await Ticket.findById(req.params.id);
  if(!t) return res.status(404).json({ error: 'Not found' });
  t.replies.push({ by:'agent', message: req.body.message, at:new Date() });
  if(req.body.action==='resolve') t.status='resolved';
  if(req.body.action==='close') t.status='closed';
  if(req.body.action==='reopen') t.status='open';
  await t.save();
  await AuditLog.create({ ticketId: t._id, traceId: uuidv4(), actor:'agent', action:'REPLY_SENT', meta:{ action:req.body.action }, timestamp:new Date() });
  res.json(t);
});

router.post('/:id/assign', auth(), requireRole('agent','admin'), validate(schemas.assign), async (req,res)=>{
  const t = await Ticket.findById(req.params.id);
  if(!t) return res.status(404).json({ error: 'Not found' });
  const assignee = await User.findById(req.body.assigneeId);
  if(!assignee) return res.status(400).json({ error: 'Assignee not found' });
  t.assignee = assignee._id;
  await t.save();
  await AuditLog.create({ ticketId: t._id, traceId: uuidv4(), actor:'agent', action:'ASSIGNED_TO_HUMAN', meta:{ assignee: assignee._id }, timestamp:new Date() });
  res.json(t);
});

export default router;
