import express from 'express';
import Config from '../models/Config.js';
import { auth, requireRole } from '../middleware/auth.js';
import { schemas, validate } from '../utils/validator.js';

const router = express.Router();

router.get('/', auth(), async (req,res)=>{
  const cfg = await Config.findOne() || await Config.create({});
  res.json(cfg);
});

router.put('/', auth(), requireRole('admin'), validate(schemas.config), async (req,res)=>{
  const cfg = await Config.findOne();
  const updated = await Config.findByIdAndUpdate(cfg ? cfg._id : (await Config.create({}))._id, req.body, { new:true });
  res.json(updated);
});

export default router;
