export default {
  testEnvironment: 'node',
  testTimeout: 30000
};
