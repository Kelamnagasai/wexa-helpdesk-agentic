import dotenv from 'dotenv';
dotenv.config();
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from '../src/models/User.js';
import Article from '../src/models/Article.js';
import Ticket from '../src/models/Ticket.js';
import Config from '../src/models/Config.js';

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/helpdesk';

async function run(){
  await mongoose.connect(MONGO_URI, { dbName: 'helpdesk' });
  await Promise.all([User.deleteMany({}), Article.deleteMany({}), Ticket.deleteMany({}), Config.deleteMany({})]);

  const passwordHash = await bcrypt.hash('password', 10);
  const [admin, agent, user] = await User.create([
    { name:'Admin', email:'admin@example.com', passwordHash, role:'admin' },
    { name:'Agent', email:'agent@example.com', passwordHash, role:'agent' },
    { name:'User',  email:'user@example.com',  passwordHash, role:'user'  },
  ]);

  await Config.create({ autoCloseEnabled: true, confidenceThreshold: 0.78, slaHours: 48 });

  const kb = await Article.insertMany([
    { title:'How to update payment method', body:'Go to billing settings and update card.', tags:['billing','payments'], status:'published' },
    { title:'Troubleshooting 500 errors', body:'Check logs, restart service, verify env.', tags:['tech','errors'], status:'published' },
    { title:'Tracking your shipment', body:'Use tracking ID on courier website.', tags:['shipping','delivery'], status:'published' },
  ]);

  await Ticket.insertMany([
    { title:'Refund for double charge', description:'I was charged twice for order #1234', category:'other', createdBy: user._id },
    { title:'App shows 500 on login', description:'Stack trace mentions auth module', category:'other', createdBy: user._id },
    { title:'Where is my package?', description:'Shipment delayed 5 days', category:'other', createdBy: user._id },
  ]);

  console.log('Seeded. Users: admin/agent/user with password "password"');
  await mongoose.disconnect();
}

run().catch(e=>{ console.error(e); process.exit(1); });
