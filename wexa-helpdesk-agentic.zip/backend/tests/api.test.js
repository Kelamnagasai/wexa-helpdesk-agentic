import mongoose from 'mongoose';
import request from 'supertest';
import dotenv from 'dotenv';
dotenv.config();
import appPkg from '../package.json' assert { type: 'json' };

let server;
let baseUrl = 'http://localhost:8080';

beforeAll(async ()=>{
  // Start the server programmatically by importing server.js? For simplicity, assume it's already running in dev.
});

test('package.json has scripts', ()=>{
  expect(appPkg.scripts.start).toBeDefined();
});

// Placeholder illustrative tests that will run once server is up in docker compose CI
test('auth endpoints require valid payload', async ()=>{
  expect(1).toBe(1);
});

afterAll(async ()=>{
  await mongoose.disconnect();
});
